# CS151 PROGRAMMING ASSIGNMENT #2

* Design grade: MRN
* Programming Grade: EMRN                                 			
* DESIGN DUE: [Next Wednesday]
* FINAL DUE: [Upper Wednesday]

## I. PROBLEM:

You are creating a head-to-head game where 2 players compete in a best-of-X match. Players will compete in a game of your choosing (similar to Rock-Paper-Scissors, but you will create your own variation with different choices and rules). Players can be either human or computer-controlled. The match continues until one player wins the majority of games (e.g., in a best-of-5, first to 3 wins).

## II. PURPOSE OF THE ASSIGNMENT

The purpose of this assignment is to give you  
1. Practice with complex nested loops
2. Experience with decision making and conditional logic
3. Practice with protecting against bad user input
4. Opportunity to manage game state across multiple rounds
5. A chance to be creative with game design
6. Experience balancing AI assistance with skill development in core programming concepts

## III. REQUIREMENTS ANALYSIS 

The first stage in your programming assignment is the requirements analysis stage. You need to make sure you understand the match structure and game requirements.

### Match Structure
The match works as follows:
1. **2 players total** (any combination: human vs human, human vs computer, or computer vs computer)
2. **Best-of-X format** where X is an odd number chosen by the user (e.g., best-of-3, best-of-5, best-of-7)
3. Players alternate going first in each game
4. **First player to win more than half the games wins the match** (e.g., first to 2 in best-of-3, first to 3 in best-of-5)
5. After the match ends, ask if players want a **rematch**
6. Track and display **total match wins** for each player across all rematches

### Player Setup Requirements
Before the match begins, for each of the 2 players your program must:
- Ask for the player's name
- Ask whether the player is "human" or "computer"
- Store this information to use throughout the match

### Game Design Requirements
You must create your own game variation with the following constraints:
- **Minimum 3 choices** (like Rock-Paper-Scissors has 3)
- **Maximum 5 choices** (like Rock-Paper-Scissors-Lizard-Spock has 5)
- **Clear rules**: At program start, explain all choices and what beats what
- **Consistent logic**: Game interactions must make sense and be fair
- **Creative theme**: Choose your own theme (elements, animals, superheroes, fantasy, etc.)

For example, you might create "Elemental Clash" with Fire-Water-Earth, where Fire burns Earth, Earth absorbs Water, and Water extinguishes Fire. Or you could create "Medieval Combat" with Sword-Shield-Bow-Magic-Stealth with your own rules for what beats what.

### Technical Requirements for Your Program

Your head-to-head game must include:

1. **Nested loop structure**: should account for the following 
   - Rematch loop (play another match?)
   - Best-of-X games within each match
   - Input validation for human players

2. **Player type handling**:
   - Human players: Get input with proper validation
   - Computer players: Make random valid choices from your game options
   - Clear indication of what each player (human or computer) chose each round

3. **Match tracking**:
   - Track wins within the current match
   - Determine when a player has won the match (more than half the games)
   - Track total match wins across all rematches
   - Display running score after each game

4. **Error checking loops**:
   - Validate all user inputs (player names, human/computer designation, best-of-X number, game choices, rematch decision)
   - Use loops to re-prompt for invalid input
   - Provide clear error messages explaining what went wrong

5. **Good HCI**: 
   - Clear game state communication (users always know what's happening)
   - Personalized output using player names
   - Clear announcements (which game in the match, current score)
   - Show running score within the match
   - Engaging presentation of computer choices and results
   - Alternate who goes first each game

### Creative Elements
You have creative freedom in:
- **Game theme and choice names** (Fire-Water-Earth, Wizard-Dragon-Knight, Laser-Shield-Asteroid, etc.)
- **Interaction explanations** (themed descriptions of why one choice beats another)
- **Output presentation style** (how you announce winners, describe rounds, etc.)

If you want an added level of difficulty, you can give computer players "personalities" with different strategies instead of purely random choices. This is not required, and should be attempted only after you've figured out how to make the regular assignment work.

## IV. DESIGN (NO AI ASSISTANCE ALLOWED)

The second stage is to design your solution based on the requirements **without any AI assistance**. Think about how to break the problem up into different smaller problems that are easier to solve. I recommend thinking through and developing your algorithm using these smaller versions:

1. **Start simple**: First design just the basic game logic (what beats what) for your chosen game without any match structure. Make sure you understand your game rules clearly.

2. **Add player setup**: How do you collect and store information for 2 players? What do you need to ask? How do you store whether each player is human or computer? Think about variable names.

3. **Design a single game**: Before worrying about best-of-X, figure out how to run one single game between two players. How do you get input from each player (considering one might be a computer)? How do you determine who won?

4. **Add computer players**: How do you handle it when a player is a computer instead of human? What are the computer's steps? How do you make the computer choose randomly among valid options?

5. **Add best-of-X match structure**: Now how do you run multiple games and track wins? How do you know when someone has won the match? How do you alternate who goes first?

6. **Add rematch capability**: How do you let players play another match? How do you track total match wins across rematches? What needs to reset between matches?

7. **Add input validation**: Where in your program does the user provide input? What could make each of those inputs invalid? Add error checking loops for each.

8. **Polish the experience**: How do you make the output clear and engaging? What announcements are needed? How do you use player names effectively?

9. If you want to make computer players with different strategies (optional), worry about that only at this point. These more advanced options might be where you use AI in the final product, so don't worry about figuring out exactly what sort of logic they will use if you don't know yet.

If you work through each part of the algorithm and slowly build it up, in the end you'll have the full program. This is called iterative development, and is a key skill to develop for solving problems. Don't stress about how you code it -- an algorithm is a time to think through the logic without stressing about code syntax.

### DESIGN SUBMISSION: [Next Wednesday]

Submit to Moodle: 
1. A Word document including:
   - Your developed algorithm showing the nested loop structure
   - A clear description of your custom game (what are the choices and what beats what?)
   - An explanation of how you handle different player types (human vs computer)
   - A brief description of what aspects of the assignment you think you've correctly included and what you are not sure is correct or got stuck on. This description is important as it helps make it clear that you understand what you've done, or where you need the most help in getting ready to write the code.

If you decided to design computer players with different strategies, note that in your document and why you designed it that way, so that you can get feedback on your design.

Your algorithm should follow the requirements of an algorithm, and contain all of the requirements for this assignment. **There should not be any code.**

## V. PROGRAMMING REQUIREMENTS - STRATEGIC AI COLLABORATION

After your design is complete and correct, you may now use AI tools strategically during implementation:

**PROGRAMMING SKILLS DEVELOPMENT:**
Remember that future assignments, quizzes, and exams will require you to write loop structures and conditional logic by hand. Use this assignment to:
- Master nested loop syntax and structure
- Understand how to track state across multiple loop iterations
- Practice managing game state (player information, scores, match progression)
- Learn to debug logical flow in multi-level nested structures

### REQUIRED MANUAL CODING (NO AI ASSISTANCE)
You MUST write these elements by hand to demonstrate your understanding:
- **All loop structures** (for loops and while loops) - this is a core learning objective
- **The nested loop architecture** (outer rematch loop, middle best-of-X loop, inner validation loops)
- **Match progression logic** (tracking game wins, determining match winner)
- **Player data management** (storing and accessing player names and types using separate variables)
- **Match scoring logic** (tracking wins within best-of-X matches and across rematches)
- **Alternating turn logic** (making sure players alternate who goes first)

### AI-ASSISTED ELEMENTS (AI ALLOWED)
You MAY use AI to help with:
- **Creative game descriptions and themed output** - making your game narrative engaging
- **Input validation error messages** - creating helpful, user-friendly error messages
- **Output formatting and presentation** - making match announcements attractive
- **Random computer player strategies** (optional challenge) - implementing non-random AI opponents
- **Code refactoring suggestions** - improving code organization after you've written the logic

### Implementation Steps:

1. **Fix design issues**: If there were issues with your design, either not meeting requirements or in the format, fix those before you start writing your code.

2. **Manual Implementation of Core Logic**: Write all your loop structures, conditional logic, player tracking, and match flow by hand. This is where the learning happens.

3. **Optional AI Enhancement**: Use AI to improve game presentation, user experience, and creative elements. Document all prompts used.

4. **Code Documentation**: Add comprehensive comments explaining your logic, especially around nested loops and state management.

5. **Testing**: Make sure it works correctly; test different player combinations, match lengths, and edge cases.
   - You do not need to submit your tests, but consider testing:
     - Different combinations of human/computer players (human vs human, human vs computer, computer vs computer)
     - Different match lengths (best-of-3, best-of-5, best-of-7)
     - Various game outcomes and match results
     - Rematch scenarios
   - Test each scenario and verify correct winners are declared and scores are tracked properly.

### Suggested Implementation and Testing Order:

1. Write and test just your basic game rules (what beats what) with hard-coded choices
2. Add and test player setup (collecting names and human/computer designation)
3. Add and test a single game between two human players
4. Add and test computer player choices (make sure random selection works)
5. Add and test best-of-X match logic (tracking wins, determining match winner)
6. Add and test the rematch loop and total match win tracking
7. Add and test all input validation loops
8. Add and test alternating who goes first each game
9. Polish the user experience and output formatting (AI assistance allowed here)

Remember to commit to GitHub between each stage of development! This helps you track your progress and makes it easier to go back if something breaks.

Remember that your game should:
1. Follow good usability/HCI principles in input and output. Be particularly mindful about what type of output is necessary for the user to understand what is going on in the match. Users should always know which game they're playing, what the current score is, and who goes first.
2. Protect the program against bad user input with error checking loops
3. State at the start the purpose of the program, your game rules (what all the choices are and what beats what), and how the match structure works.

---
#### **Hint on random numbers:**
To create a random number in Python, use the method `randint(a,b)`. It gives you a number randomly chosen in the range a<= number <=b. For instance, if your game has 3 choices and you number them 1, 2, 3, you could write:

```python
import random
computer_choice = random.randint(1, 3)
```
The variable computer_choice now holds a value that is randomly either 1, 2, or 3. This is useful for having computer players make random choices in your game.

---

Complete a flowchart on your game to submit. Use the process of drawing the flowchart as a chance to pay attention to if the logic of your game makes sense, especially the nested loop structure for the match. Use the flowchart to help you determine how to test your code, but you do not need to submit the test cases.

## VI. EXAMPLE GAME VARIATIONS

Here are some example themes to inspire you. **Remember: Your game must be original (not copied from these examples)** and the rules must make logical sense!

- **Elemental Clash** (3 choices): Fire-Water-Earth (Fire burns Earth, Earth absorbs Water, Water extinguishes Fire)
- **Superhero Showdown** (5 choices): Strength-Speed-Intelligence-Flight-Magic  
- **Medieval Combat** (5 choices): Sword-Shield-Bow-Magic-Stealth
- **Space Adventure** (4 choices): Laser-Shield-Asteroid-Wormhole

Think creatively about your theme and make sure your rules are clear and balanced!

## VII. ASSIGNMENT REMINDERS

Follow the programming assignment requirements document for comments, formatting, etc. Follow the honor code guidelines outlined in the syllabus and at https://www.loyola.edu/academics/computer-science/current-students/honor-code.

**CRITICAL AI USAGE BOUNDARIES:**
- **Never ask AI to write your loop structures** - this defeats the learning purpose
- **Never ask AI to solve the match flow logic** - you must understand how the best-of-X progression works
- **Never ask AI to write your player tracking or state management code** - understanding data flow is essential
- **Use AI to make your game more engaging, not to do your programming thinking**
- **You must be able to explain every line of loop and conditional logic in your program**

## VIII. REFLECTION

Write a short reflection about the programming assignment in **reflection.txt** no more than a page:

**Problem-Solving Experience:**
1. What did you learn about nested loops and managing complex program flow?
2. What was difficult about designing and implementing the match structure?
3. What was it like tracking state across multiple levels (rematch → match → game)?

**Loop Structure Development:**
4. What was challenging about writing nested loops by hand?
5. How did you debug issues in your loop logic?
6. What loop programming skills did you develop that will help you write complex structures independently?

**AI Collaboration Experience:**
7. How did AI help vs. hinder your learning in this assignment?
8. Which creative or presentational elements did AI help you improve?
9. What technical assistance (if any) did you get from AI, and how did you ensure you understood it?

**Manual Coding Challenges:**
10. What aspects of the core logic (loops, conditionals, data management) gave you the most trouble when coding by hand?
11. How confident do you feel writing similar nested loop structures without AI assistance?

**Learning Reflection:**
12. What would you do differently next time?
13. What surprised you about managing match state and score tracking?
14. How has your understanding of loops and program structure evolved through this assignment?

## IX. FINAL SUBMISSION due [Upper Wednesday]

1. **To GitHub:**
   1. Your main.py file (with comprehensive comments distinguishing manual vs. AI-assisted code)
   2. Your reflection of the programming assignment in reflection.txt

2. **To Moodle:**
   1. Your final algorithm in Word, including the changes you made based on the design feedback, in designFinal.docx
   2. Your flowchart showing the nested loop structure
   3. **Screenshots or saved conversations** showing your AI interactions for creative and technical assistance (if you used AI)

***Remember to commit and push your GitHub project frequently.***