# Import required module
import random
import time #Ai assisted

# Define main game function, "Elemental Battle!"
def elemental_battle_game():
    # Game introduction and rules display
    print("Welcome to the Elemental Battle Game!")
    print("Rules:")
    print("Fire burns Earth")
    print("Earth absorbs Water")
    print("Water extinguishes Fire")

    # Define func for the rounds
    def play_elemental_rounds(number_to_win=2):
        elements = {1: "Fire", 2: "Water", 3: "Earth"}
        player_wins = 0
        computer_wins = 0
     # Best of 3 rounds (first to 2 wins)

    # Match loop: continue until one player reaches the required wins
        while player_wins < number_to_win and computer_wins < number_to_win:
            # Remind player of choices and rules before each round
            print("Choose your element:")
            print("1 - Fire, 2 - Water, 3 - Earth")

         # Player input with error checking, if their input is invalid
            player_input = input("Enter your choice (1-3): ")
            if not player_input.isdigit():
                print("Invalid input. Please enter a number (1, 2, or 3).")
                continue

            player_choice = int(player_input)
            if player_choice not in (1, 2, 3):
                print("Invalid choice. Please enter 1, 2, or 3.")
                continue
            print("Computer is thinking:")
            for i in range(1, 2, 3):  # Adds computer buffer time inside round loop
                    print(i)
                    time.sleep(1) #Ai assisted


            # Computer randomly selects an element (fire, water, earth)
            computer_choice = random.randint(1, 3)
            player_element = elements[player_choice]
            computer_element = elements[computer_choice]

            # Reveals both choices after round
            print(f"You chose: {player_element}")
            print(f"Computer chose: {computer_element}")

            # Determine round outcome based on rules
            if player_element == computer_element:
                print("This round is a tie!")
            elif   ((player_element == "Fire" and computer_element == "Earth") or
                    (player_element == "Earth" and computer_element == "Water") or
                    (player_element == "Water" and computer_element == "Fire")):
                print("You win this round!")
                player_wins += 1
            else:
                print("Computer wins this round!")
                computer_wins += 1

        # Display current score to user
        print(f"Score -> You: {player_wins}, Computer: {computer_wins}")

    # End match: declare winner
        if player_wins > computer_wins:
            print("Congratulations! You won the match!")
        else:
            print("Computer won the match! Better luck next time!")



    #Will run the match
    play_elemental_rounds()

    #Offer rematch option to user
    rematch = input("Would you like a rematch? (yes/no): ").strip().lower()
    if rematch == "yes":
            return elemental_battle_game()  # Restart game
    elif rematch == "no":
        print("Thanks for playing!")
    else:
        print("Invalid input. Please try again.")
        exit()




#Controlled start of the game
elemental_battle_game()


